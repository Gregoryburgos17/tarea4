<?php
include('utils.php');
 
$sql="insert into prueba (Nombre) values ('amadis')" ;
$datos=conexion::ejecutar($sql);
var_dump($datos);