<?php
 define('DB_HOST','localhost');
 define('DB_USER','root');
 define('DB_PASS','mysql');
 define('DB_NAME','prueba');